
import React, { useState, Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Environment } from '@react-three/drei';
import Experience from './components/Experience';
import UIOverlay from './components/UIOverlay';
import { TreeMorphState } from './types';
import { COLORS } from './constants';

const App: React.FC = () => {
  const [morphState, setMorphState] = useState<TreeMorphState>(TreeMorphState.SCATTERED);

  const toggleState = () => {
    setMorphState(prev => 
      prev === TreeMorphState.SCATTERED ? TreeMorphState.TREE_SHAPE : TreeMorphState.SCATTERED
    );
  };

  return (
    <div className="w-full h-screen relative bg-[#010d08]">
      <UIOverlay state={morphState} onToggle={toggleState} />
      
      <Canvas shadows dpr={[1, 2]}>
        <PerspectiveCamera makeDefault position={[0, 5, 20]} fov={45} />
        
        <color attach="background" args={[COLORS.DEEP_SPACE]} />
        
        {/* Cinematic Lighting */}
        <ambientLight intensity={0.2} />
        <spotLight 
          position={[10, 20, 10]} 
          angle={0.15} 
          penumbra={1} 
          intensity={2} 
          castShadow 
          color={COLORS.GOLD_BRIGHT}
        />
        <pointLight position={[-10, -10, -10]} intensity={1} color={COLORS.EMERALD_LIGHT} />
        
        <Suspense fallback={null}>
          <Experience morphState={morphState} />
          <Environment preset="night" />
        </Suspense>

        <OrbitControls 
          enablePan={false} 
          minDistance={10} 
          maxDistance={40} 
          autoRotate={morphState === TreeMorphState.TREE_SHAPE}
          autoRotateSpeed={0.5}
        />
      </Canvas>

      {/* Decorative Gradient Overlay */}
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_center,_transparent_0%,_rgba(1,13,8,0.8)_100%)]" />
    </div>
  );
};

export default App;
