
import React from 'react';
import { TreeMorphState } from '../types';
import { Sparkles, Trees, Boxes } from 'lucide-react';

interface UIOverlayProps {
  state: TreeMorphState;
  onToggle: () => void;
}

const UIOverlay: React.FC<UIOverlayProps> = ({ state, onToggle }) => {
  return (
    <div className="absolute inset-0 z-10 flex flex-col justify-between p-8 pointer-events-none select-none">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div className="space-y-1">
          <h1 className="text-4xl font-extrabold tracking-tighter text-[#d4af37] flex items-center gap-3">
            <Sparkles className="w-8 h-8" />
            ARIX <span className="font-light text-emerald-100">SIGNATURE</span>
          </h1>
          <p className="text-xs uppercase tracking-[0.3em] text-emerald-500 font-bold">
            Interactive 3D Christmas Experience
          </p>
        </div>
        
        <div className="bg-black/40 backdrop-blur-md border border-[#d4af37]/30 p-4 rounded-xl text-right">
          <div className="text-[10px] uppercase tracking-widest text-[#d4af37]/60 mb-1">State Configuration</div>
          <div className="text-lg font-medium text-emerald-50">
            {state === TreeMorphState.TREE_SHAPE ? 'Conical Formation' : 'Entropy Field'}
          </div>
        </div>
      </div>

      {/* Footer / Controls */}
      <div className="flex flex-col md:flex-row justify-between items-end gap-6">
        <div className="max-w-xs text-sm text-emerald-100/60 font-light leading-relaxed">
          Crafted with emerald precision and metallic gold essence. 
          Use the control system to manifest the Arix Signature Formation.
        </div>

        <button
          onClick={onToggle}
          className="pointer-events-auto group relative flex items-center gap-4 px-8 py-4 bg-[#0a5c3e] hover:bg-[#0d7a52] text-[#d4af37] font-bold rounded-full border-2 border-[#d4af37] shadow-[0_0_30px_rgba(212,175,55,0.3)] transition-all duration-500 transform hover:scale-105 active:scale-95"
        >
          <div className="absolute inset-0 rounded-full bg-gradient-to-r from-yellow-500/0 via-yellow-200/20 to-yellow-500/0 animate-pulse" />
          
          {state === TreeMorphState.SCATTERED ? (
            <>
              <Trees className="w-6 h-6 transition-transform group-hover:rotate-12" />
              <span className="tracking-widest uppercase text-sm">Assemble Tree</span>
            </>
          ) : (
            <>
              <Boxes className="w-6 h-6 transition-transform group-hover:scale-125" />
              <span className="tracking-widest uppercase text-sm">Initiate Scatter</span>
            </>
          )}
        </button>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-1/2 right-4 -translate-y-1/2 flex flex-col gap-8">
        {[0, 1, 2].map((i) => (
          <div key={i} className="w-[1px] h-24 bg-gradient-to-b from-transparent via-[#d4af37]/40 to-transparent" />
        ))}
      </div>
    </div>
  );
};

export default UIOverlay;
