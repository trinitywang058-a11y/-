
import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { ParticleData, TreeMorphState } from '../types';
import { COLORS, TREE_CONFIG } from '../constants';

interface TreeParticlesProps {
  particles: ParticleData[];
  morphState: TreeMorphState;
}

const TreeParticles: React.FC<TreeParticlesProps> = ({ particles, morphState }) => {
  const needleRef = useRef<THREE.InstancedMesh>(null!);
  const ornamentRef = useRef<THREE.InstancedMesh>(null!);
  
  // Ref to track the current animation progress (0 to 1)
  const progress = useRef(0);
  
  // Temporary objects for calculations to avoid GC
  const _obj = useMemo(() => new THREE.Object3D(), []);
  const _vPos = useMemo(() => new THREE.Vector3(), []);
  const _vTarget = useMemo(() => new THREE.Vector3(), []);

  const needles = useMemo(() => particles.filter(p => p.type === 'needle'), [particles]);
  const ornaments = useMemo(() => particles.filter(p => p.type === 'ornament'), [particles]);

  useFrame((state) => {
    const targetProgress = morphState === TreeMorphState.TREE_SHAPE ? 1 : 0;
    progress.current = THREE.MathUtils.lerp(progress.current, targetProgress, TREE_CONFIG.MORPH_SPEED);

    const time = state.clock.elapsedTime;

    // Update Needles
    needles.forEach((p, i) => {
      const p1 = p.scatterPos;
      const p2 = p.treePos;
      
      _vPos.set(p1[0], p1[1], p1[2]);
      _vTarget.set(p2[0], p2[1], p2[2]);
      
      _obj.position.lerpVectors(_vPos, _vTarget, progress.current);
      
      // Floating/swirling animation when scattered
      if (progress.current < 0.9) {
        const swirl = (1 - progress.current);
        _obj.position.x += Math.cos(time * 0.5 + i * 0.1) * 0.2 * swirl;
        _obj.position.z += Math.sin(time * 0.5 + i * 0.1) * 0.2 * swirl;
        _obj.position.y += Math.sin(time + i) * 0.15 * swirl;
      }
      
      // Orient needles to point slightly outward from the center when in tree shape
      if (progress.current > 0.5) {
        _obj.lookAt(0, _obj.position.y, 0);
        _obj.rotateX(Math.PI / 2 + 0.2); // Point downwards slightly
      } else {
        _obj.rotation.set(
          p.rotation[0] + (progress.current * Math.PI * 4), 
          p.rotation[1] + time * 0.2, 
          p.rotation[2]
        );
      }
      
      _obj.scale.setScalar(p.scale);
      _obj.updateMatrix();
      needleRef.current.setMatrixAt(i, _obj.matrix);
    });
    needleRef.current.instanceMatrix.needsUpdate = true;

    // Update Ornaments
    ornaments.forEach((p, i) => {
      const p1 = p.scatterPos;
      const p2 = p.treePos;
      
      _vPos.set(p1[0], p1[1], p1[2]);
      _vTarget.set(p2[0], p2[1], p2[2]);
      
      _obj.position.lerpVectors(_vPos, _vTarget, progress.current);
      
      // Breathing scale effect for high-end feel
      const pulse = Math.sin(time * 1.5 + i) * 0.08;
      _obj.scale.setScalar(p.scale * (1 + pulse * (1 - progress.current * 0.5)));
      
      _obj.rotation.y = time * 0.3;
      _obj.updateMatrix();
      ornamentRef.current.setMatrixAt(i, _obj.matrix);
    });
    ornamentRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <group>
      {/* Needle Layer: Refined for higher density */}
      <instancedMesh ref={needleRef} args={[undefined, undefined, needles.length]} castShadow>
        <boxGeometry args={[0.03, 0.35, 0.03]} />
        <meshStandardMaterial 
          color={COLORS.EMERALD_LIGHT} 
          emissive={COLORS.EMERALD_DARK}
          emissiveIntensity={0.8}
          roughness={0.1}
          metalness={0.9}
        />
      </instancedMesh>

      {/* Ornament Layer: Luxurious Golden Spheres */}
      <instancedMesh ref={ornamentRef} args={[undefined, undefined, ornaments.length]} castShadow>
        <sphereGeometry args={[0.1, 20, 20]} />
        <meshStandardMaterial 
          color={COLORS.GOLD_BRIGHT} 
          emissive={COLORS.GOLD_METALLIC}
          emissiveIntensity={1.2}
          metalness={1}
          roughness={0.05}
          envMapIntensity={2}
        />
      </instancedMesh>
    </group>
  );
};

export default TreeParticles;
