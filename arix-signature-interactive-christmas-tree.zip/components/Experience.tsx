
import React, { useMemo } from 'react';
import { Bloom, EffectComposer, Noise, Vignette } from '@react-three/postprocessing';
import TreeParticles from './TreeParticles';
import { TreeMorphState, ParticleData } from '../types';
import { COLORS, TREE_CONFIG } from '../constants';

interface ExperienceProps {
  morphState: TreeMorphState;
}

const Experience: React.FC<ExperienceProps> = ({ morphState }) => {
  // Pre-calculate dual positions for all particles
  const particles = useMemo(() => {
    const data: ParticleData[] = [];
    
    // 1. Generate Needles (Emerald Green)
    // We use a dense phyllotaxis-based distribution for a lush organic feel
    for (let i = 0; i < TREE_CONFIG.NEEDLE_COUNT; i++) {
      // Scatter Position (Cloud/Sphere)
      const u = Math.random();
      const v = Math.random();
      const theta = 2 * Math.PI * u;
      const phi = Math.acos(2 * v - 1);
      const r = TREE_CONFIG.SCATTER_RADIUS * Math.cbrt(Math.random());
      const scatterX = r * Math.sin(phi) * Math.cos(theta);
      const scatterY = r * Math.sin(phi) * Math.sin(theta);
      const scatterZ = r * Math.cos(phi);

      // Tree Position (Cone with slight jitter for natural density)
      const t = i / TREE_CONFIG.NEEDLE_COUNT;
      const height = t * TREE_CONFIG.HEIGHT;
      const baseRadius = (1 - t) * TREE_CONFIG.RADIUS;
      const angle = i * 2.39996; // Golden angle
      
      // Add a bit of thickness to the "shell" of the tree
      const shellThickness = Math.random() * 0.4;
      const radius = baseRadius - shellThickness;
      
      const treeX = radius * Math.cos(angle);
      const treeZ = radius * Math.sin(angle);
      const treeY = height - TREE_CONFIG.HEIGHT / 2;

      data.push({
        scatterPos: [scatterX, scatterY, scatterZ],
        treePos: [treeX, treeY, treeZ],
        rotation: [Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI],
        scale: 0.15 + Math.random() * 0.35,
        type: 'needle'
      });
    }

    // 2. Generate Ornaments (Gold)
    for (let i = 0; i < TREE_CONFIG.ORNAMENT_COUNT; i++) {
      const u = Math.random();
      const v = Math.random();
      const theta = 2 * Math.PI * u;
      const phi = Math.acos(2 * v - 1);
      const r = (TREE_CONFIG.SCATTER_RADIUS + 2) * Math.cbrt(Math.random());
      
      const t = Math.random();
      const height = t * TREE_CONFIG.HEIGHT;
      const radius = (1 - t) * (TREE_CONFIG.RADIUS + 0.2);
      const angle = Math.random() * Math.PI * 2;

      data.push({
        scatterPos: [
          r * Math.sin(phi) * Math.cos(theta),
          r * Math.sin(phi) * Math.sin(theta),
          r * Math.cos(phi)
        ],
        treePos: [
          radius * Math.cos(angle),
          height - TREE_CONFIG.HEIGHT / 2,
          radius * Math.sin(angle)
        ],
        rotation: [0, 0, 0],
        scale: 0.6 + Math.random() * 1.0,
        type: 'ornament'
      });
    }

    return data;
  }, []);

  return (
    <>
      <TreeParticles particles={particles} morphState={morphState} />
      
      {/* Central glow point light for the tree core */}
      <pointLight 
        position={[0, 0, 0]} 
        intensity={morphState === TreeMorphState.TREE_SHAPE ? 15 : 2} 
        color={COLORS.GOLD_BRIGHT} 
        distance={15}
        decay={2}
      />
      
      {/* Post-processing for that Luxury Cinematic Glow */}
      <EffectComposer multisampling={4}>
        <Bloom 
          intensity={2.2} 
          luminanceThreshold={0.15} 
          luminanceSmoothing={0.8} 
          height={480} 
        />
        <Noise opacity={0.03} />
        <Vignette eskil={false} offset={0.05} darkness={1.2} />
      </EffectComposer>
    </>
  );
};

export default Experience;
