
export const COLORS = {
  EMERALD_DARK: '#042a1b',
  EMERALD_LIGHT: '#0a5c3e',
  GOLD_METALLIC: '#d4af37',
  GOLD_BRIGHT: '#f9d71c',
  DEEP_SPACE: '#010d08'
};

export const TREE_CONFIG = {
  NEEDLE_COUNT: 15000, // Increased from 4000 for high density
  ORNAMENT_COUNT: 450, // Increased from 120 for richer decoration
  HEIGHT: 12,
  RADIUS: 5,
  SCATTER_RADIUS: 25,
  MORPH_SPEED: 0.035 // Slightly slower morph for more "cinematic" feel with high density
};
